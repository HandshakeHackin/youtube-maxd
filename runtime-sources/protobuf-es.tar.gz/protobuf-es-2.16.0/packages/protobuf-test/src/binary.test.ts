// Copyright 2021-2026 Buf Technologies, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { suite, test } from "node:test";
import * as assert from "node:assert";
import {
  create,
  isFieldSet,
  setExtension,
  getExtension,
  toBinary,
  fromBinary,
  fromJsonString,
} from "@bufbuild/protobuf";
import {
  type MessageInitShape,
  type DescMessage,
  protoInt64,
} from "@bufbuild/protobuf";
import { EmptySchema, StructSchema, ValueSchema } from "@bufbuild/protobuf/wkt";
import {
  RepeatedScalarValuesMessageSchema,
  ScalarValuesMessageSchema,
} from "./gen/ts/extra/msg-scalar_pb.js";
import {
  MapsMessageBug1183Schema,
  MapsMessageSchema,
} from "./gen/ts/extra/msg-maps_pb.js";
import { MessageFieldMessageSchema } from "./gen/ts/extra/msg-message_pb.js";
import {
  Proto2ExtendeeSchema,
  string_ext,
} from "./gen/ts/extra/extensions-proto2_pb.js";
import { OneofMessageSchema } from "./gen/ts/extra/msg-oneof_pb.js";
import { JsonNamesMessageSchema } from "./gen/ts/extra/msg-json-names_pb.js";
import { JSTypeProto2NormalMessageSchema } from "./gen/ts/extra/jstype-proto2_pb.js";
import { TestAllTypesProto3Schema } from "./gen/ts/google/protobuf/test_messages_proto3_pb.js";
import { Proto3MessageSchema } from "./gen/ts/extra/proto3_pb.js";
import { compileMessage } from "./helpers.js";
import { BinaryReader, BinaryWriter, WireType } from "@bufbuild/protobuf/wire";

void suite(`binary serialization`, () => {
  testBinary(ScalarValuesMessageSchema, {
    doubleField: 0.75,
    floatField: -0.75,
    int64Field: protoInt64.parse(-1),
    uint64Field: protoInt64.uParse(1),
    int32Field: -123,
    fixed64Field: protoInt64.uParse(1),
    fixed32Field: 123,
    boolField: true,
    stringField: "hello world",
    bytesField: new Uint8Array([
      104, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100,
    ]),
    uint32Field: 123,
    sfixed32Field: -123,
    sfixed64Field: protoInt64.parse(-1),
    sint32Field: -1,
    sint64Field: protoInt64.parse(-1),
  });
  testBinary(RepeatedScalarValuesMessageSchema, {
    doubleField: [0.75, 0, 1],
    floatField: [0.75, -0.75],
    int64Field: [protoInt64.parse(-1), protoInt64.parse(-2)],
    uint64Field: [protoInt64.uParse(1), protoInt64.uParse(2)],
    int32Field: [-123, 500],
    fixed64Field: [protoInt64.uParse(1), protoInt64.uParse(99)],
    fixed32Field: [123, 999],
    boolField: [true, false, true],
    stringField: ["hello", "world"],
    bytesField: [
      new Uint8Array([104, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100]),
    ],
    uint32Field: [123, 123],
    sfixed32Field: [-123, -123, -123],
    sfixed64Field: [
      protoInt64.parse(-1),
      protoInt64.parse(-2),
      protoInt64.parse(100),
    ],
    sint32Field: [-1, -2, 999],
    sint64Field: [
      protoInt64.parse(-1),
      protoInt64.parse(-99),
      protoInt64.parse(99),
    ],
  });
  testBinary(MessageFieldMessageSchema, {
    messageField: { name: "test" },
    repeatedMessageField: [{ name: "a" }, { name: "b" }],
  });
  testBinary(MapsMessageSchema, {
    strStrField: { a: "str", b: "xx" },
    strInt32Field: { a: 123, b: 455 },
    strInt64Field: { a: protoInt64.parse(123) },
    strBoolField: { a: true, b: false },
    strBytesField: {
      a: new Uint8Array([104, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100]),
    },
    int32StrField: { 123: "hello" },
    int64StrField: { "9223372036854775807": "hello" },
    boolStrField: { true: "yes", false: "no" },
    strMsgField: {
      a: {},
    },
    int32MsgField: {
      "32": {},
    },
    int64MsgField: {
      "64": {},
    },
    strEnuField: { a: 0, b: 1, c: 2 },
    int32EnuField: { 1: 0, 2: 1, 0: 2 },
    int64EnuField: { "-1": 0, "2": 1, "0": 2 },
    strStructField: { a: { x: 1 } },
  });
  void test(MapsMessageBug1183Schema.typeName, () => {
    const str128bytes = "x".repeat(128);
    const msg = create(MapsMessageBug1183Schema, {
      map: {
        [str128bytes]: 1,
      },
    });
    const bytes = toBinary(MapsMessageBug1183Schema, msg);
    const msg2 = fromBinary(MapsMessageBug1183Schema, bytes);
    assert.deepStrictEqual(msg2.map, {
      [str128bytes]: 1,
    });
    assert.strictEqual(msg2.$unknown, undefined);
  });
  testBinary(OneofMessageSchema, {
    message: {
      case: "foo",
      value: {
        name: "max",
        toggle: false,
      },
    },
    scalar: { case: undefined },
    enum: { case: undefined },
  });
  testBinary(JsonNamesMessageSchema, {
    a: "a",
    b: "b",
    c: "c",
  });
  testBinary(JSTypeProto2NormalMessageSchema, {
    fixed64Field: protoInt64.uParse(123),
    int64Field: protoInt64.parse(123),
    sfixed64Field: protoInt64.parse(123),
    sint64Field: protoInt64.parse(123),
    uint64Field: protoInt64.uParse(123),
    repeatedFixed64Field: [protoInt64.uParse(123)],
    repeatedInt64Field: [protoInt64.parse(123)],
    repeatedSfixed64Field: [protoInt64.parse(123)],
    repeatedSint64Field: [protoInt64.parse(123)],
    repeatedUint64Field: [protoInt64.uParse(123)],
  });
  testBinary(StructSchema, {
    fields: {
      a: { kind: { case: "numberValue", value: 123 } },
      b: { kind: { case: "stringValue", value: "abc" } },
    },
  });
  void suite("Value", () => {
    testBinary(ValueSchema, {
      kind: { case: "boolValue", value: true },
    });
    void suite("Value with Struct field", () => {
      testBinary(ValueSchema, {
        kind: {
          case: "structValue",
          value: {
            fields: {
              foo: { kind: { case: "numberValue", value: 1 } },
            },
          },
        },
      });
    });
  });
  void suite("extensions", () => {
    void test("encode and decode an extension", () => {
      const extendee = create(Proto2ExtendeeSchema);
      setExtension(extendee, string_ext, "foo");
      assert.strictEqual(
        getExtension(
          fromBinary(
            Proto2ExtendeeSchema,
            toBinary(Proto2ExtendeeSchema, extendee),
          ),
          string_ext,
        ),
        "foo",
      );
    });
  });
  void test("error for invalid data", () => {
    const msg = create(ScalarValuesMessageSchema, {
      uint32Field: -1, // -1 is invalid for a uint
    });
    assert.throws(() => toBinary(ScalarValuesMessageSchema, msg), {
      name: "Error",
      message:
        "cannot encode field spec.ScalarValuesMessage.uint32_field to binary: invalid uint32: -1",
    });
  });
  void test("map fields with message_encoding DELIMITED", async () => {
    const descMessage = await compileMessage(`
      edition = "2023";
      option features.message_encoding = DELIMITED;
      package example;
      message User {
        string username = 1;
        Project singular = 2;
        map<string, Project> map = 3;
      }
      message Project {
        string name = 4;
        User user = 5;
      }
    `);
    const message = fromJsonString(
      descMessage,
      `
      {
        "username":  "a",
        "singular":  {
          "name":  "b",
          "user":  {
            "username":  "c"
          }
        },
        "map":  {
          "d":  {
            "name":  "e",
            "user":  {
              "username":  "f"
            }
          }
        }
      }
    `,
    );
    const bytes = toBinary(descMessage, message);
    const r = new BinaryReader(bytes);

    // username
    let [fieldNo] = r.tag();
    assert.strictEqual(fieldNo, 1);
    assert.strictEqual(r.string(), "a");
    {
      // singular
      let [fieldNo, wireType] = r.tag();
      assert.strictEqual(fieldNo, 2);
      assert.strictEqual(wireType, WireType.StartGroup);
      // singular.name
      [fieldNo] = r.tag();
      assert.strictEqual(fieldNo, 4);
      assert.strictEqual(r.string(), "b");
      {
        // singular.user
        let [fieldNo, wireType] = r.tag();
        assert.strictEqual(fieldNo, 5);
        assert.strictEqual(wireType, WireType.StartGroup);
        // singular.user.username
        [fieldNo] = r.tag();
        assert.strictEqual(fieldNo, 1);
        assert.strictEqual(r.string(), "c");
        // singular.user end group
        [fieldNo, wireType] = r.tag();
        assert.strictEqual(fieldNo, 5);
        assert.strictEqual(wireType, WireType.EndGroup);
      }
      // singular end group
      [fieldNo, wireType] = r.tag();
      assert.strictEqual(fieldNo, 2);
      assert.strictEqual(wireType, WireType.EndGroup);
    }
    {
      // map
      let [fieldNo, wireType] = r.tag();
      assert.strictEqual(fieldNo, 3);
      assert.strictEqual(wireType, WireType.LengthDelimited);
      assert.ok(r.uint32() > 0);
      {
        // map["d"] (map key)
        let [fieldNo] = r.tag();
        assert.strictEqual(fieldNo, 1);
        assert.strictEqual(r.string(), "d");
      }
      {
        // map["d"] (map value)
        let [fieldNo, wireType] = r.tag();
        assert.strictEqual(fieldNo, 2);
        assert.strictEqual(wireType, WireType.LengthDelimited);
        assert.ok(r.uint32() > 0);
        // map["d"].name
        [fieldNo] = r.tag();
        assert.strictEqual(fieldNo, 4);
        assert.strictEqual(r.string(), "e");
        {
          // map["d"].user
          let [fieldNo, wireType] = r.tag();
          assert.strictEqual(fieldNo, 5);
          assert.strictEqual(wireType, WireType.StartGroup);
          // map["d"].user.username
          [fieldNo] = r.tag();
          assert.strictEqual(fieldNo, 1);
          assert.strictEqual(r.string(), "f");
          // map["d"].user end group
          [fieldNo, wireType] = r.tag();
          assert.strictEqual(fieldNo, 5);
          assert.strictEqual(wireType, WireType.EndGroup);
        }
      }
    }
    assert.strictEqual(r.pos, r.len);
  });
});

void suite("UTF-8 validation on binary input", () => {
  const invalid = new Uint8Array([0xa0, 0xb0, 0xc0, 0xd0]);
  const fieldOneStringBytes = new BinaryWriter()
    .tag(1, WireType.LengthDelimited)
    .bytes(invalid)
    .finish();
  void test("rejects invalid UTF-8 on proto3 string", async () => {
    const desc = await compileMessage(`
      syntax="proto3";
      message M { string f = 1; }
    `);
    assert.throws(() => fromBinary(desc, fieldOneStringBytes));
  });
  void test("rejects invalid UTF-8 on edition 2023 string", async () => {
    const desc = await compileMessage(`
      edition="2023";
      message M { string f = 1; }
    `);
    assert.throws(() => fromBinary(desc, fieldOneStringBytes));
  });
  void test("accepts invalid UTF-8 on proto2 string", async () => {
    const desc = await compileMessage(`
      syntax="proto2";
      message M { optional string f = 1; }
    `);
    fromBinary(desc, fieldOneStringBytes);
  });
  void test("accepts invalid UTF-8 when features.utf8_validation = NONE", async () => {
    const desc = await compileMessage(`
      edition="2023";
      message M {
        string f = 1 [features.utf8_validation = NONE];
      }
    `);
    fromBinary(desc, fieldOneStringBytes);
  });
  void test("rejects invalid UTF-8 in map key", async () => {
    const desc = await compileMessage(`
      syntax="proto3";
      message M { map<string, string> f = 1; }
    `);
    const entry = new BinaryWriter()
      .tag(1, WireType.LengthDelimited)
      .bytes(invalid)
      .tag(2, WireType.LengthDelimited)
      .bytes(new Uint8Array())
      .finish();
    const bytes = new BinaryWriter()
      .tag(1, WireType.LengthDelimited)
      .bytes(entry)
      .finish();
    assert.throws(() => fromBinary(desc, bytes));
  });
  void test("rejects invalid UTF-8 in map value", async () => {
    const desc = await compileMessage(`
      syntax="proto3";
      message M { map<string, string> f = 1; }
    `);
    const entry = new BinaryWriter()
      .tag(1, WireType.LengthDelimited)
      .bytes(new Uint8Array())
      .tag(2, WireType.LengthDelimited)
      .bytes(invalid)
      .finish();
    const bytes = new BinaryWriter()
      .tag(1, WireType.LengthDelimited)
      .bytes(entry)
      .finish();
    assert.throws(() => fromBinary(desc, bytes));
  });
  void test("rejects invalid UTF-8 in repeated string", async () => {
    const desc = await compileMessage(`
      syntax="proto3";
      message M { repeated string f = 1; }
    `);
    assert.throws(() => fromBinary(desc, fieldOneStringBytes));
  });
});

void suite("map entry with repeated value field on binary input", () => {
  // A map entry is a message with the key in field 1 and the value in field 2.
  // If field 2 occurs more than once in a single entry, the regular rules for
  // repeated occurrences of a singular field apply: message values are merged,
  // scalar values are replaced.
  void test("merges message values", () => {
    const bytes = new BinaryWriter()
      .tag(MapsMessageSchema.field.strMsgField.number, WireType.LengthDelimited)
      .fork()
      .tag(1, WireType.LengthDelimited)
      .string("k")
      .tag(2, WireType.LengthDelimited)
      .bytes(
        toBinary(
          MapsMessageSchema,
          create(MapsMessageSchema, { strInt32Field: { a: 1, x: 1 } }),
        ),
      )
      .tag(2, WireType.LengthDelimited)
      .bytes(
        toBinary(
          MapsMessageSchema,
          create(MapsMessageSchema, { strInt32Field: { b: 2, x: 2 } }),
        ),
      )
      .join()
      .finish();
    const msg = fromBinary(MapsMessageSchema, bytes);
    assert.deepStrictEqual(msg.strMsgField.k.strInt32Field, {
      a: 1,
      b: 2,
      x: 2,
    });
  });
  void test("keeps message value when followed by an empty value", () => {
    const bytes = new BinaryWriter()
      .tag(MapsMessageSchema.field.strMsgField.number, WireType.LengthDelimited)
      .fork()
      .tag(1, WireType.LengthDelimited)
      .string("k")
      .tag(2, WireType.LengthDelimited)
      .bytes(
        toBinary(
          MapsMessageSchema,
          create(MapsMessageSchema, { strInt32Field: { a: 1 } }),
        ),
      )
      .tag(2, WireType.LengthDelimited)
      .bytes(new Uint8Array(0))
      .join()
      .finish();
    const msg = fromBinary(MapsMessageSchema, bytes);
    assert.deepStrictEqual(msg.strMsgField.k.strInt32Field, { a: 1 });
  });
  void test("merges google.protobuf.Struct values", () => {
    // Struct is represented as JsonObject, and takes a separate path.
    const bytes = new BinaryWriter()
      .tag(
        MapsMessageSchema.field.strStructField.number,
        WireType.LengthDelimited,
      )
      .fork()
      .tag(1, WireType.LengthDelimited)
      .string("k")
      .tag(2, WireType.LengthDelimited)
      .bytes(
        toBinary(
          StructSchema,
          create(StructSchema, {
            fields: {
              a: { kind: { case: "numberValue", value: 1 } },
              x: { kind: { case: "numberValue", value: 1 } },
            },
          }),
        ),
      )
      .tag(2, WireType.LengthDelimited)
      .bytes(
        toBinary(
          StructSchema,
          create(StructSchema, {
            fields: {
              b: { kind: { case: "numberValue", value: 2 } },
              x: { kind: { case: "numberValue", value: 2 } },
            },
          }),
        ),
      )
      .join()
      .finish();
    const msg = fromBinary(MapsMessageSchema, bytes);
    assert.deepStrictEqual(msg.strStructField, { k: { a: 1, b: 2, x: 2 } });
  });
  void test("replaces scalar values", () => {
    const bytes = new BinaryWriter()
      .tag(MapsMessageSchema.field.strStrField.number, WireType.LengthDelimited)
      .fork()
      .tag(1, WireType.LengthDelimited)
      .string("k")
      .tag(2, WireType.LengthDelimited)
      .string("first")
      .tag(2, WireType.LengthDelimited)
      .string("last")
      .join()
      .finish();
    const msg = fromBinary(MapsMessageSchema, bytes);
    assert.deepStrictEqual(msg.strStrField, { k: "last" });
  });
});

void suite("fromBinary recursion limit", () => {
  // Nested TestAllTypesProto3 via its recursive_message field, as wire bytes.
  function makeNestedRecursiveMessage(depth: number): Uint8Array {
    let message = new Uint8Array(0);
    const fieldNo = TestAllTypesProto3Schema.field.recursiveMessage.number;
    for (let i = 0; i < depth; i++) {
      message = new BinaryWriter()
        .tag(fieldNo, WireType.LengthDelimited)
        .bytes(message)
        .finish();
    }
    return message;
  }

  test("rejects deeply nested messages instead of overflowing the stack", () => {
    assert.throws(
      () =>
        fromBinary(TestAllTypesProto3Schema, makeNestedRecursiveMessage(1000)),
      /maximum recursion depth of 100 reached/,
    );
  });
  test("accepts nesting within the default limit", () => {
    assert.doesNotThrow(() =>
      fromBinary(TestAllTypesProto3Schema, makeNestedRecursiveMessage(50)),
    );
  });
  test("honors a custom recursionLimit", () => {
    assert.throws(
      () =>
        fromBinary(TestAllTypesProto3Schema, makeNestedRecursiveMessage(5), {
          recursionLimit: 3,
        }),
      /maximum recursion depth of 3 reached/,
    );
    assert.doesNotThrow(() =>
      fromBinary(TestAllTypesProto3Schema, makeNestedRecursiveMessage(5), {
        recursionLimit: 10,
      }),
    );
  });

  test("honors recursionLimit for unknown groups", () => {
    // A run of StartGroup tags at field 1, which is unknown to Empty. fromBinary
    // skips unknown fields, and skipping a group recurses for each nested group.
    function makeNestedUnknownGroups(
      depth: number,
      closed: boolean,
    ): Uint8Array {
      const writer = new BinaryWriter();
      for (let i = 0; i < depth; i++) {
        writer.tag(1, WireType.StartGroup);
      }
      if (closed) {
        for (let i = 0; i < depth; i++) {
          writer.tag(1, WireType.EndGroup);
        }
      }
      return writer.finish();
    }
    assert.throws(
      () => fromBinary(EmptySchema, makeNestedUnknownGroups(10000, false)),
      /maximum recursion depth reached/,
    );
    assert.throws(
      () =>
        fromBinary(EmptySchema, makeNestedUnknownGroups(10000, false), {
          readUnknownFields: false,
        }),
      /maximum recursion depth reached/,
    );
    assert.doesNotThrow(() =>
      fromBinary(EmptySchema, makeNestedUnknownGroups(50, true)),
    );
    assert.throws(
      () =>
        fromBinary(EmptySchema, makeNestedUnknownGroups(50, true), {
          recursionLimit: 10,
        }),
      /maximum recursion depth reached/,
    );
  });

  test("uses the remaining recursion budget for unknown nested groups", () => {
    // The helper function nest() creates a nested message with variable depth.
    // The innermost message also holds unknown groups with variable depth.
    const unknownNo =
      Math.max(...TestAllTypesProto3Schema.fields.map((f) => f.number)) + 1;
    const recursiveNo = TestAllTypesProto3Schema.field.recursiveMessage.number;
    function nest(messageDepth: number, groupDepth: number): Uint8Array {
      const inner = new BinaryWriter();
      for (let i = 0; i < groupDepth; i++) {
        inner.tag(unknownNo, WireType.StartGroup);
      }
      for (let i = 0; i < groupDepth; i++) {
        inner.tag(unknownNo, WireType.EndGroup);
      }
      let message = inner.finish();
      for (let i = 0; i < messageDepth; i++) {
        message = new BinaryWriter()
          .tag(recursiveNo, WireType.LengthDelimited)
          .bytes(message)
          .finish();
      }
      return message;
    }
    // groupDepth (60) is within the limit on its own, but combined with the
    // surrounding message depth (60) it exceeds recursionLimit and is rejected.
    assert.throws(
      () => fromBinary(TestAllTypesProto3Schema, nest(60, 60)),
      /maximum recursion depth reached/,
    );
    // The same group depth is accepted when the message depth leaves room.
    assert.doesNotThrow(() =>
      fromBinary(TestAllTypesProto3Schema, nest(30, 60)),
    );
  });
});

void suite("negative zero serialization", () => {
  test("singular float with -0 is set and round-trips", () => {
    const msg = create(Proto3MessageSchema, { singularFloatField: -0 });
    assert.strictEqual(
      isFieldSet(msg, Proto3MessageSchema.field.singularFloatField),
      true,
    );
    const bytes = toBinary(Proto3MessageSchema, msg);
    assert.ok(bytes.length > 0);
    const back = fromBinary(Proto3MessageSchema, bytes);
    assert.ok(Object.is(back.singularFloatField, -0));
  });
  test("singular float with +0 is unset and omitted", () => {
    const msg = create(Proto3MessageSchema, { singularFloatField: 0 });
    assert.ok(!isFieldSet(msg, Proto3MessageSchema.field.singularFloatField));
    assert.strictEqual(toBinary(Proto3MessageSchema, msg).length, 0);
  });
  test("singular int32 with -0 is unset and omitted", () => {
    const msg = create(Proto3MessageSchema, { singularInt32Field: -0 });
    assert.ok(!isFieldSet(msg, Proto3MessageSchema.field.singularInt32Field));
    assert.strictEqual(toBinary(Proto3MessageSchema, msg).length, 0);
  });
});

function testBinary<Desc extends DescMessage>(
  desc: Desc,
  init: MessageInitShape<Desc>,
) {
  void test(desc.typeName, () => {
    const msg = create(desc, init);
    assert.deepStrictEqual(fromBinary(desc, toBinary(desc, msg)), msg);
  });
}
